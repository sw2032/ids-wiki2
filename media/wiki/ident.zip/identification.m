function varargout = identification(varargin)
% IDENTIFICATION MATLAB code for identification.fig
%      IDENTIFICATION, by itself, creates a new IDENTIFICATION or raises the existing
%      singleton*.
%
%      H = IDENTIFICATION returns the handle to a new IDENTIFICATION or the handle to
%      the existing singleton*.
%
%      IDENTIFICATION('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in IDENTIFICATION.M with the given input arguments.
%
%      IDENTIFICATION('Property','Value',...) creates a new IDENTIFICATION or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before identification_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to identification_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help identification

% Last Modified by GUIDE v2.5 10-Sep-2016 03:10:46

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @identification_OpeningFcn, ...
                   'gui_OutputFcn',  @identification_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before identification is made visible.
function identification_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to identification (see VARARGIN)

% Choose default command line output for identification
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes identification wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = identification_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Serial_obj=serial('COM4'); 
set(Serial_obj,'BaudRate',9600,'Parity','none','DataBits',8,'StopBits',1 ,...
    'BytesAvailableFcnCount',20,'BytesAvailableFcnMode','byte',...
    'BytesAvailableFcn',{@bytes,handles} );
fopen(Serial_obj);  
set(handles.text4,'String','Status: Online');
set(handles.text5,'String','Status: Recording');
fwrite(Serial_obj,[165 81 9 21 0 0 0 0 0 0 mod(sum([165 81 9 21 0 0 0 0 0 0]),127)],'uint8');

function bytes(obj,~,handles)
n = get(obj,'BytesAvailable');
recdta1=fread(obj,1,'uint8'); if(recdta1~=165) return ; end
recdta2=fread(obj,1,'uint8'); if(recdta2~= 81) return ; end
recdta3=fread(obj,1,'uint8'); if(recdta3~=  1) return ; end
recdta4=fread(obj,1,'uint8'); if(recdta4~=  2) return ; end
%[n recdta1 recdta2 recdta3 recdta4]
recdta_ID_8=fread(obj,8,'uint8'); 
recdta_NO_1=fread(obj,1,'uint8'); 
recdta_TM_6=fread(obj,6,'uint8'); 
recdta_CK_1=fread(obj,1,'uint8'); 
strr=['READ ID:' num2str(recdta_ID_8') ' NO:' num2str(recdta_NO_1') ' TM:' num2str(recdta_TM_6') ' CK:' num2str(recdta_CK_1') '\r\n'];
fid=fopen('./scaned_data.txt','a+');
fprintf(fid,strr);
fclose(fid);

global xdata;
xdata=[xdata recdta_NO_1];
%���ֱ��ͼ������
[n,y] = hist(xdata);
 maxN = max(n);
%������ʾx,y��������
%axis([0 1.2 0 maxN+2]) 
%����ֱ��ͼ�����ݻ��Ƴ�ͼ��
bar(handles.axes1,y,n);
for i = 1:length(y)
    %ֱ��ͼ�������ݶԲ��룬����ˮƽ�ʹ�ֱ���� �����Բο�search  Document �е�text����
    %text(y(i),n(i)+0.5,num2str(n(i)),'VerticalAlignment','middle','HorizontalAlignment','center');
end
%drawnow

% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
copyfile('scaned_data.txt','scaned_data_temp.txt');
system('notepad scaned_data_temp.txt ');

% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
fid=fopen('./scaned_data.txt','w+');
global xdata;
xdata=[];
fclose(fid);


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

delete(instrfindall);
set(handles.text4,'String','Status: Offline');
set(handles.text5,'String','Status: Not Recording');


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure
delete(instrfindall);
set(handles.text4,'String','Status: Offline');
set(handles.text5,'String','Status: Not Recording');
delete(hObject);
